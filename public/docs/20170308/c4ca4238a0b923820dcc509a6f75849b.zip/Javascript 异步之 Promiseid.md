# Javascript 异步之 Promiseid

昨天晚上学了 `Javascript` 中的 `Promise`, 感觉这个功能很强大。我在用 `nodejs` 进行 `mysql` 数据库操作的时候，因为是异步进行的，所有有时候接连进行多次查询的时候，会套嵌很多层。用了 `Promise` 之后，感觉能把套嵌的层数缩减为一层，而且又比较符合同步编程的直觉，读起来很方便。所以今天就把代码重构了一下。真是很好用。  


参考资料:  
[阮一峰的博客](http://es6.ruanyifeng.com/#docs/promise)  
[MDN](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Promise/then)  

在学习的过程中了解到 `nodejs` 中有一个库可以进行 `Promise.try` 的写法，明天了解一下    
[joepie91's Ramblings](http://cryto.net/~joepie91/blog/2016/05/11/what-is-promise-try-and-why-does-it-matter/)