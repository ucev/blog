# highlight.js 测试

这是测试 *highlight.js* de 功能和用法的

``` javascript
function a() {
  var i = 1;
  i += 1;
  return i;
}
```